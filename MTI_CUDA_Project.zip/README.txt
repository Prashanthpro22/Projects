MTI CUDA Project

Files:
- mti_cuda.cu : CUDA C++ implementation for 2-pulse and 3-pulse MTI cancellers
- mti_input.csv : Sample test input file (I, Q pairs)
- mti_output.csv : Generated after running the program

Build Command:
    nvcc mti_cuda.cu -o mti_cuda

Run:
    ./mti_cuda

All parameters (numPulses, numRanges, mode, filenames) are defined inside the source.
