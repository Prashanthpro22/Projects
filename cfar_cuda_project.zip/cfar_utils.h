#ifndef CFAR_UTILS_H
#define CFAR_UTILS_H

#include <vector>
#include <string>
#include <cuComplex.h>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>

inline bool readComplexCSV(const std::string& filename,
                    std::vector<cuFloatComplex>& data,
                    int& rows,
                    int& cols) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "[Error] Failed to open input CSV file." << std::endl;
        return false;
    }

    std::string line;
    rows = 0;
    cols = -1;
    std::regex complex_pattern(R"(([+-]?[0-9.]+)([+-][0-9.]+)i)");

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string cell;
        int thisCols = 0;

        while (std::getline(ss, cell, ',')) {
            std::smatch match;
            if (std::regex_match(cell, match, complex_pattern)) {
                float real = std::stof(match[1].str());
                float imag = std::stof(match[2].str());
                data.push_back(make_cuFloatComplex(real, imag));
                thisCols++;
            } else {
                std::cerr << "[Error] Invalid complex number format: " << cell << std::endl;
                return false;
            }
        }

        if (cols == -1) cols = thisCols;
        else if (cols != thisCols) {
            std::cerr << "[Error] Inconsistent column count in row " << rows << std::endl;
            return false;
        }

        rows++;
    }

    file.close();
    return true;
}

inline bool writeDetectionCSV(const std::string& filename,
                       const std::vector<int>& output,
                       int rows, int cols) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "[Error] Could not write output CSV." << std::endl;
        return false;
    }

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            file << output[i * cols + j];
            if (j < cols - 1) file << ",";
        }
        file << "\n";
    }

    file.close();
    return true;
}

#endif