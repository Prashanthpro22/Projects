#!/bin/bash

# Test Runner Script for CFAR CUDA Project

echo "[INFO] Cleaning and building the project..."
make clean && make

if [ $? -ne 0 ]; then
    echo "[ERROR] Build failed. Exiting."
    exit 1
fi

INPUT=test_input.csv
OUTPUT=test_output.csv

echo "[INFO] Running CFAR application on ${INPUT}..."
./cfar_app ${INPUT} ${OUTPUT}

if [ $? -ne 0 ]; then
    echo "[ERROR] CFAR application failed."
    exit 1
fi

echo "[INFO] CFAR execution completed. Output saved to ${OUTPUT}"

# Optional: Show preview of output
echo "[INFO] Output Preview:"
head -n 5 ${OUTPUT}
