#include <iostream>
#include <vector>
#include <cuda_runtime.h>
#include <cuComplex.h>
#include "cfar_utils.h"

extern void launch_cfar(cuFloatComplex* d_input, int* d_output,
                        int numPulses, int numSamples,
                        int guardCells, int refCells,
                        float alpha, int cfarType,
                        cudaStream_t stream = 0);

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <input_csv_file> [output_csv_file]" << std::endl;
        return 1;
    }

    std::string inputCSV = argv[1];
    std::string outputCSV = (argc > 2) ? argv[2] : "cfar_output.csv";

    std::vector<cuFloatComplex> inputData;
    int rows = 0, cols = 0;

    if (!readComplexCSV(inputCSV, inputData, rows, cols)) {
        return 1;
    }

    size_t numElements = rows * cols;

    int guardCells = 2;
    int refCells = 4;
    float alpha = 1.5f;
    int cfarType = 0;

    std::vector<int> outputData(numElements);

    cuFloatComplex* d_input;
    int* d_output;
    cudaMalloc(&d_input, numElements * sizeof(cuFloatComplex));
    cudaMalloc(&d_output, numElements * sizeof(int));

    cudaMemcpy(d_input, inputData.data(), numElements * sizeof(cuFloatComplex), cudaMemcpyHostToDevice);

    launch_cfar(d_input, d_output, rows, cols, guardCells, refCells, alpha, cfarType);

    cudaMemcpy(outputData.data(), d_output, numElements * sizeof(int), cudaMemcpyDeviceToHost);

    writeDetectionCSV(outputCSV, outputData, rows, cols);

    std::cout << "CFAR detection completed. Output saved to: " << outputCSV << std::endl;

    cudaFree(d_input);
    cudaFree(d_output);

    return 0;
}