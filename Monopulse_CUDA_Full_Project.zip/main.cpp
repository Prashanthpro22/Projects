// main.cpp
#include <iostream>
#include <vector>
#include <cstdint>

extern "C" unsigned short DP_TRCA_Angle_Error_Calculation_CUDA(
    unsigned int in_uiNoofPulses,
    short in_sBin,
    unsigned int numBins,
    const double* h_inISumData,
    const double* h_inQSumData,
    const double* h_inIAziIData,
    const double* h_inIAziQData,
    const double* h_inIEleIData,
    const double* h_inIEleQData,
    const uint8_t* h_detectionReport,
    double *out_dAzError,
    double *out_dElError);

int main() {
    unsigned int numPulses = 1024;
    unsigned int numBins = 128;
    short binIndex = 64;

    size_t total = size_t(numPulses) * numBins;

    std::vector<double> ISum(total, 100.0);
    std::vector<double> QSum(total, 50.0);
    std::vector<double> IAziI(total, 20.0);
    std::vector<double> IAziQ(total, 10.0);
    std::vector<double> IEleI(total, 15.0);
    std::vector<double> IEleQ(total, 8.0);
    std::vector<uint8_t> Detect(total, 1);

    double azErr = 0.0, elErr = 0.0;

    unsigned short count =
        DP_TRCA_Angle_Error_Calculation_CUDA(
            numPulses, binIndex, numBins,
            ISum.data(), QSum.data(),
            IAziI.data(), IAziQ.data(),
            IEleI.data(), IEleQ.data(),
            Detect.data(),
            &azErr, &elErr);

    std::cout << "Valid pulses      = " << count << "\n";
    std::cout << "Azimuth Error     = " << azErr << "\n";
    std::cout << "Elevation Error   = " << elErr << "\n";

    return 0;
}
